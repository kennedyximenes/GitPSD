package com.example.kennedy.expsd;

/**
 * Created by kennedy ximenes on 18/07/2017.
 */

public class Config {

    public static final String FILE_UPLOAD_URL = "http://192.168.0.102:8000/json";
    public static final String IMAGE_DIRECTORY_NAME = "ExPSD";

}

